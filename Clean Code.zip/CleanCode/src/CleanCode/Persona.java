package CleanCode;

public class Persona {

    String nombre;
    String apellido1;
    String apellido2;
    int nroDNI;
    char letraDNI;
    int edad;
    char sexo;

    public Persona(String nombre, String apellido1, String apellido2,
            int nroDNI, char letraDNI, int edad, char sexo) {
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.nroDNI = nroDNI;
        this.letraDNI = letraDNI;
        this.edad = edad;
        this.sexo = sexo;
    }
    public Persona() {
        this.nombre = "xxxx";
        this.apellido1 = "xxxx";
        this.apellido2 = "xxxx";
        this.nroDNI = 0000000;
        this.letraDNI = '?';
        this.edad = 00;
        this.sexo = '?';
    }
    public String to(){
String r = ("Datos Persona: \nNombre: " + nombre + "\nApellidos: " + apellido1 + " " + apellido2 + 
                 "\nDNI: " + nroDNI + letraDNI + "\nEdad: " + edad + "\nSexo: " + sexo + "\n");
return r;
    }
}