package CleanCode;

public class Profesor extends Persona {
    
    public int NRP;
    
    public Profesor( String nombre, String apellido1, String apellido2,
            int nroDNI, char letraDNI, int edad, char sexo, int NRP ) {
                
        super(nombre, apellido1, apellido2, nroDNI, letraDNI, edad, sexo);
        this.NRP = NRP;
    }
    public Profesor(){
        this.nombre = "xxxx";
        this.apellido1 = "xxxx";
        this.apellido2 = "xxxx";
        this.nroDNI = 0000000;
        this.letraDNI = '?';
        this.edad = 00;
        this.sexo = '?';
    }
}

