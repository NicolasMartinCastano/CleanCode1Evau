package CleanCode;

public class CleanCode {

    public static void main(String[] args) {
        Alumno Nicolas = new Alumno();
        Profesor Pablo = new Profesor();

        Nicolas.nombre = "Nicolás";
        Nicolas.apellido1 = "Martín";
        Nicolas.apellido2 = "Castaño";
        Nicolas.nroDNI = 9824331;
        Nicolas.letraDNI = 'L';
        Nicolas.edad = 18;
        Nicolas.sexo = 'H';
        Nicolas.NIA = 1234123;

        Pablo.nombre = "Pablo";
        Pablo.apellido1 = "Fernandez";
        Pablo.apellido2 = "Castillo";
        Pablo.nroDNI = 1234567;
        Pablo.letraDNI = 'B';
        Pablo.edad = 34;
        Pablo.sexo = 'H';
        Pablo.NRP = 1321432;

        System.out.println(Nicolas.toString() + Nicolas.NIA);
        
        System.out.println("\n");
        
        System.out.println(Pablo.toString() + Pablo.NRP);
    }
}
